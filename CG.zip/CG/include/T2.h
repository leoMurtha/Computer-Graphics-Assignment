#ifndef _T2_H_
#define _T2_H_

using namespace std;

#include <Transformations.h>

#define WINDOW_WIDTH 1000
#define WINDOW_HEIGHT 600
#define fps 100/6
#define LEFT 119
#define RIGHT 115
#define UP 101
#define DWN 103

#endif