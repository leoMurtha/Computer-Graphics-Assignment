# Computer-Graphics-Assignment
A 2D and 3D spyder that moves.
