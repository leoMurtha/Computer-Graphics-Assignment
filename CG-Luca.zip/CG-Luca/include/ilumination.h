#ifndef _ILUMINATION_H_
#define _ILUMINATION_H_


void ilumination();

#endif 