#ifndef _DEVICEINPUT_H_
#define _DEVICEINPUT_H_

#include <GL/glut.h>

void mouse(GLint , GLint , GLint , GLint );
void keyboardSpecial(GLint , GLint , GLint );

#endif